package com.nestcam.watch8.mobile;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.pm.ActivityInfo;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import com.nestcam.watch8.shared.RtcViewer;
import org.json.JSONArray;
import org.json.JSONObject;
import org.webrtc.SurfaceViewRenderer;
import java.time.Instant;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private NestApi api;
    private TextView state;
    private Spinner cameraSelector;
    private SurfaceViewRenderer surface;
    private RtcViewer rtc;
    private final ArrayList<JSONObject> cameras = new ArrayList<>();
    private String session = "", streamingDevice = "";
    private Runnable extension;
    private LinearLayout content;
    private FrameLayout screenRoot, inlineVideo, fullOverlay;
    private boolean fullscreen = false;
    private int previousOrientation, previousUiFlags;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(10,18,29));
        getWindow().setNavigationBarColor(Color.rgb(10,18,29));
        api = new NestApi(this);
        buildUi();
        loadCachedDevices();
    }
    private int dp(float x) { return (int)(x*getResources().getDisplayMetrics().density+.5f); }
    private TextView text(String s, int sp, int color) {
        TextView v = new TextView(this); v.setText(s); v.setTextColor(color); v.setTextSize(sp);
        v.setPadding(0,dp(6),0,dp(6)); return v;
    }
    private Button button(String s, LinearLayout box, Runnable action) {
        Button b = new Button(this); b.setText(s); b.setAllCaps(false);
        b.setTextColor(Color.WHITE); b.setBackgroundTintList(ColorStateList.valueOf(0xff243C5A));
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(-1,dp(47));p.bottomMargin=dp(6);
        box.addView(b,p);b.setOnClickListener(v->action.run());return b;
    }
    private void title(String s) { content.addView(text(s,16,0xffD7E8FA)); }
    private void buildUi() {
        ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.setBackgroundColor(0xff0C1521);
        content=new LinearLayout(this);content.setPadding(dp(17),dp(8),dp(17),dp(32));content.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(content);
        screenRoot = new FrameLayout(this);
        screenRoot.addView(scroll, new FrameLayout.LayoutParams(-1, -1));
        setContentView(screenRoot);
        TextView heading=text("NestCam Live · 手机控制台",21,Color.WHITE);heading.setGravity(Gravity.CENTER);
        content.addView(heading);
        state=text("准备就绪。首次使用请填写 OAuth Client ID 与 Secret。",13,0xffB5CCE0);
        content.addView(state);
        title("① 授权与摄像头");
        button("配置 OAuth（首次一次）",content,this::configure);
        button("打开 Google Nest 授权",content,()->{
            try { startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse(api.authorizationUrl()))); }
            catch(Exception ex){ status(ex.getMessage()); }
        });
        button("粘贴授权回调网址 / code",content,this::pasteAuth);
        button("刷新摄像头列表（自动检测）",content,this::refresh);
        cameraSelector=new Spinner(this);
        cameraSelector.setBackgroundTintList(ColorStateList.valueOf(0xffA4BDD6));
        content.addView(cameraSelector,new LinearLayout.LayoutParams(-1,dp(48)));
        title("② 手机实时监控");
        inlineVideo = new FrameLayout(this);
        inlineVideo.setBackgroundColor(Color.BLACK);
        surface=new SurfaceViewRenderer(this);
        inlineVideo.addView(surface, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout.LayoutParams videoParams=new LinearLayout.LayoutParams(-1,dp(236));videoParams.bottomMargin=dp(10);
        content.addView(inlineVideo,videoParams);
        rtc=new RtcViewer(this,surface,new RtcViewer.Listener(){
            @Override public void onOffer(String offer){
                if(cameras.isEmpty() || cameraSelector.getSelectedItemPosition()<0){status("没有摄像头，请先刷新列表");return;}
                JSONObject d=cameras.get(cameraSelector.getSelectedItemPosition());
                String selected=d.optString("name");
                status("正在请求 Nest WebRTC 直播...");
                execute(()->api.start(selected,offer),answer->{
                    api.rememberDevice(selected);
                    streamingDevice=selected;session=answer.optString("mediaSessionId");
                    rtc.setAnswer(answer.optString("answerSdp"));
                    scheduleExtend(answer.optString("expiresAt"));
                });
            }
            @Override public void onStatus(String s){status(s);}
        });
        button("▶ 手机播放实时视频",content,()->{
            if(cameras.isEmpty()) {status("先点刷新摄像头列表");return;}
            if(!session.isEmpty()) stopPhone();
            rtc.start();
        });
        button("■ 停止播放",content,this::stopPhone);
        button("⛶ 全屏横屏查看（完整画面）",content,this::enterFullscreen);
        title("③ Galaxy Watch 8");
        content.addView(text("在已配对的 Watch 8 上安装手表 APK，打开后即可请求本机直播。手机负责令牌、SDM API 和直播续期；画面由手表自身解码。",13,0xffB5CCE0));
        button("检查手表连接",content,()->com.google.android.gms.wearable.Wearable.getNodeClient(this)
            .getConnectedNodes().addOnSuccessListener(nodes -> status("已连接 Wear OS 节点: " + nodes.size()))
            .addOnFailureListener(e->status("手表连接检查失败："+e.getClass().getSimpleName())));
        content.addView(text("安全：本 App 不预装密钥；你输入的 Client Secret、Token 会由 Android Keystore 在手机本地加密。授权使用外部 Chrome 浏览器，不使用 WebView。",12,0xff8BA5BE));
        button("清除本机全部授权信息",content,()->new AlertDialog.Builder(this)
            .setTitle("确认清除？").setMessage("删除本机保存的 Client ID、Secret 和访问令牌，不会删除 Google Cloud 项目。")
            .setNegativeButton("取消",null).setPositiveButton("清除",(d,w)->{stopPhone();api.clear();cameras.clear();state.setText("已清除本机授权信息");}).show());
    }
    private void status(String s){ ui.post(()->state.setText(s)); }
    private interface Task { JSONObject run() throws Exception; }
    private interface Done { void run(JSONObject v); }
    private void execute(Task task,Done done) {
        io.execute(()->{try{JSONObject r=task.run();ui.post(()->done.run(r));}
          catch(Exception e){status("连接失败: " + (e.getMessage()==null?e.getClass().getSimpleName():e.getMessage()));}});
    }
    private void field(String heading, boolean secret, String initial, java.util.function.Consumer<String> ok) {
        EditText edit=new EditText(this);edit.setTextColor(Color.BLACK);edit.setText(initial);
        edit.setSingleLine(!heading.contains("回调"));
        edit.setInputType(secret ? InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_PASSWORD :
                InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_VARIATION_NORMAL);
        LinearLayout box=new LinearLayout(this);box.setPadding(dp(22),0,dp(22),0);box.addView(edit,new LinearLayout.LayoutParams(-1,-2));
        new AlertDialog.Builder(this).setTitle(heading).setView(box).setNegativeButton("取消",null)
            .setPositiveButton("保存",(d,w)->ok.accept(edit.getText().toString().trim())).show();
    }
    private void configure() {
        field("OAuth Client ID",false,api.clientId(),id->{
            field("Client Secret（本机加密，不上传 GitHub）",true,"",secret->{
                try { api.configure(id,secret);status("OAuth 配置已安全保存在手机"); }
                catch(Exception e){status(e.getMessage());}
            });
        });
    }
    private void pasteAuth() {
        ClipboardManager cb=(ClipboardManager)getSystemService(CLIPBOARD_SERVICE);
        String clip="";
        if(cb.hasPrimaryClip()) {
            ClipData data=cb.getPrimaryClip();
            if(data!=null&&data.getItemCount()>0) clip=data.getItemAt(0).coerceToText(this).toString();
        }
        field("粘贴含 code= 的回调 URL 或授权码",false,clip,value->{
            status("正在兑换 Google 授权令牌...");
            execute(()->{api.exchange(value);return new JSONObject().put("ok",true);},v->{status("授权成功，正在自动发现摄像头");refresh();});
        });
    }
    // Reuse previously identified camera IDs; only the existing Refresh button forces network discovery.
    private void loadCachedDevices() {
        JSONArray saved = api.cachedDevices();
        if (saved.length() > 0) showDevices(saved, true);
    }
    private void showDevices(JSONArray found, boolean cached) {
        ArrayList<JSONObject> next=new ArrayList<>();ArrayList<String> names=new ArrayList<>();
        int preferred=0;
        String remembered = api.preferredDevice();
        for(int i=0;i<found.length();i++){
            JSONObject d=found.optJSONObject(i);
            if(d==null || !NestApi.webrtc(d)) continue;
            String n=NestApi.title(d);
            if(remembered.isEmpty() && n.equalsIgnoreCase("backyard")) preferred=next.size();
            if(!remembered.isEmpty() && remembered.equals(d.optString("name"))) preferred=next.size();
            next.add(d);names.add(n+" · WebRTC");
        }
        cameras.clear();cameras.addAll(next);
        ArrayAdapter<String> adapter=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,names);
        cameraSelector.setAdapter(adapter);
        if(!names.isEmpty()) cameraSelector.setSelection(preferred);
        if(!next.isEmpty()) status(cached ? "已读取上次摄像头；可直接播放（长时间失效请手动刷新）"
                : "发现 "+next.size()+" 台摄像头；手机和 Watch 8 可请求直播");
        else status("暂无支持 WEB_RTC 的摄像头。请核对 Google Home 授权");
    }
    private void refresh(){
        io.execute(()->{
            try {
                JSONArray found=api.devices();
                ui.post(()->showDevices(found, false));
            } catch(Exception e){status("获取设备失败："+e.getMessage());}
        });
    }
    // Move the same renderer between views; never recreate the peer/session for fullscreen.
    // Aspect-FIT is already configured in the original shared RtcViewer (no cropping).
    private void enterFullscreen() {
        if (fullscreen || surface == null) return;
        previousOrientation = getRequestedOrientation();
        previousUiFlags = getWindow().getDecorView().getSystemUiVisibility();
        fullscreen = true;
        inlineVideo.removeView(surface);
        fullOverlay = new FrameLayout(this);
        fullOverlay.setBackgroundColor(Color.BLACK);
        fullOverlay.addView(surface, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        Button exit = new Button(this);
        exit.setText("退出全屏");exit.setAllCaps(false);
        exit.setTextColor(Color.WHITE);
        exit.setBackgroundTintList(ColorStateList.valueOf(0xAA243C5A));
        FrameLayout.LayoutParams closeParams = new FrameLayout.LayoutParams(dp(122), dp(45), Gravity.RIGHT|Gravity.TOP);
        closeParams.setMargins(0, dp(12), dp(14), 0);
        fullOverlay.addView(exit, closeParams);
        exit.setOnClickListener(v -> exitFullscreen());
        screenRoot.addView(fullOverlay, new FrameLayout.LayoutParams(-1,-1));
        getWindow().getDecorView().setSystemUiVisibility(previousUiFlags | View.SYSTEM_UI_FLAG_FULLSCREEN
                | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
    }
    private void exitFullscreen() {
        if (!fullscreen) return;
        fullscreen = false;
        fullOverlay.removeView(surface);
        screenRoot.removeView(fullOverlay);
        fullOverlay = null;
        inlineVideo.addView(surface, new FrameLayout.LayoutParams(-1, -1));
        getWindow().getDecorView().setSystemUiVisibility(previousUiFlags);
        setRequestedOrientation(previousOrientation);
    }
    @Override public void onBackPressed() {
        if (fullscreen) exitFullscreen();
        else super.onBackPressed();
    }
    private void scheduleExtend(String expiry) {
        if(extension!=null)ui.removeCallbacks(extension);
        if(session.isEmpty())return;
        long millis=220_000;
        try {millis=Instant.parse(expiry).toEpochMilli()-System.currentTimeMillis()-45_000;}catch(Exception ignored){}
        millis=Math.max(30_000,Math.min(millis,240_000));
        extension=()->{
            final String old=session,device=streamingDevice;
            if(old.isEmpty())return;
            execute(()->api.extend(device,old),json->{
                if(old.equals(session))scheduleExtend(json.optString("expiresAt"));
            });
        };
        ui.postDelayed(extension,millis);
    }
    private void stopPhone(){
        if(extension!=null)ui.removeCallbacks(extension);
        extension=null;
        String prior=session,dev=streamingDevice;
        session="";streamingDevice="";
        if(rtc!=null)rtc.stop();
        if(!prior.isEmpty())io.execute(()->{try{api.stop(dev,prior);}catch(Exception ignored){}});
    }
    @Override protected void onDestroy(){stopPhone();if(rtc!=null)rtc.release();io.shutdown();super.onDestroy();}
}
