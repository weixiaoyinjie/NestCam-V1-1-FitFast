package com.nestcam.watch8.mobile;

import android.content.Context;
import android.net.Uri;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/** API calls are blocking: only call on worker threads, never the UI thread. */
public final class NestApi {
    public static final String DEVICE_ACCESS_PROJECT = "3de5d5c2-6b3e-4708-86ac-199205c10c60";
    public static final String REDIRECT = "https://www.google.com";
    private static final String API_ROOT = "https://smartdevicemanagement.googleapis.com/v1/";
    private final SecureStore store;

    public NestApi(Context context) { store = new SecureStore(context); }
    public boolean configured() { return !store.get("clientId").isEmpty() && !store.get("clientSecret").isEmpty(); }
    public boolean linked() { return !store.get("refreshToken").isEmpty(); }
    public void configure(String id, String secret) {
        if (!id.endsWith(".apps.googleusercontent.com")) throw new IllegalArgumentException("请填写完整 OAuth Client ID");
        if (secret.isEmpty()) throw new IllegalArgumentException("必须输入 Client Secret");
        store.put("clientId", id.trim()); store.put("clientSecret", secret.trim());
    }
    public void clear() { store.clear(); }
    public String clientId() { return store.get("clientId"); }
    public String authorizationUrl() {
        String id = clientId();
        if (id.isEmpty()) throw new IllegalStateException("先在手机里填写 Client ID 和 Secret");
        return "https://nestservices.google.com/partnerconnections/" + DEVICE_ACCESS_PROJECT + "/auth"
            + "?redirect_uri=" + Uri.encode(REDIRECT) + "&access_type=offline&prompt=consent"
            + "&client_id=" + Uri.encode(id) + "&response_type=code"
            + "&scope=" + Uri.encode("https://www.googleapis.com/auth/sdm.service");
    }
    public void exchange(String codeOrUrl) throws Exception {
        String code = codeOrUrl.trim();
        if (code.contains("code=")) {
            Uri uri = Uri.parse(code);
            code = uri.getQueryParameter("code");
        }
        if (code == null || code.isEmpty()) throw new IllegalArgumentException("没有找到授权 code");
        JSONObject json = tokenCall("code", code);
        saveToken(json);
        if (store.get("refreshToken").isEmpty()) throw new IOException("Google 未返回 refresh_token，请使用 prompt=consent 重新授权");
    }
    private JSONObject tokenCall(String type, String credential) throws Exception {
        String form = "client_id=" + enc(store.get("clientId"))
                + "&client_secret=" + enc(store.get("clientSecret"))
                + ("code".equals(type) ? "&code=" + enc(credential) + "&redirect_uri=" + enc(REDIRECT)
                   + "&grant_type=authorization_code" : "&refresh_token=" + enc(credential) + "&grant_type=refresh_token");
        return call("POST", "https://oauth2.googleapis.com/token", null,
                form.getBytes(StandardCharsets.UTF_8), "application/x-www-form-urlencoded");
    }
    private static String enc(String s) throws Exception { return URLEncoder.encode(s, "UTF-8"); }
    private void saveToken(JSONObject j) {
        String access = j.optString("access_token");
        if (access.isEmpty()) throw new IllegalStateException("Google 没有返回 access_token");
        store.put("accessToken", access);
        String refresh = j.optString("refresh_token");
        if (!refresh.isEmpty()) store.put("refreshToken", refresh);
        long sec = j.optLong("expires_in", 3600);
        store.put("expiresAtMs", Long.toString(System.currentTimeMillis() + sec * 1000));
    }
    private synchronized String token() throws Exception {
        if (!configured()) throw new IOException("请先配置 OAuth Client ID 与 Secret");
        long expiry;
        try { expiry = Long.parseLong(store.get("expiresAtMs")); } catch (Exception e) { expiry = 0; }
        String access = store.get("accessToken");
        if (!access.isEmpty() && System.currentTimeMillis() + 90000 < expiry) return access;
        String refresh = store.get("refreshToken");
        if (refresh.isEmpty()) throw new IOException("尚未授权 Nest Cam，请在手机 App 完成 Google 授权");
        saveToken(tokenCall("refresh", refresh));
        return store.get("accessToken");
    }
    // The cache stores camera metadata ONLY, not stream sessions or authentication tokens.
    // A successful explicit refresh updates it; a WATCH LIST uses it without an extra Google devices.list call.
    public JSONArray cachedDevices() {
        if (!linked()) return new JSONArray();
        try {
            String cached = store.get("cachedCameraListV1");
            return cached.isEmpty() ? new JSONArray() : new JSONArray(cached);
        } catch (Exception ignored) { return new JSONArray(); }
    }
    public JSONArray devicesPreferCached() throws Exception {
        JSONArray cached = cachedDevices();
        return cached.length() > 0 ? cached : devices();
    }
    public JSONArray devices() throws Exception {
        JSONObject json = sdGet(API_ROOT + "enterprises/" + DEVICE_ACCESS_PROJECT + "/devices");
        JSONArray devices = json.optJSONArray("devices") == null ? new JSONArray() : json.getJSONArray("devices");
        try { store.put("cachedCameraListV1", devices.toString()); }
        catch (Exception ignored) { /* Successful discovery should still work without cache. */ }
        return devices;
    }
    public String preferredDevice() { return store.get("preferredCameraIdV1"); }
    public void rememberDevice(String deviceId) {
        if (!deviceId.isEmpty()) {
            try { store.put("preferredCameraIdV1", deviceId); }
            catch (Exception ignored) { /* Do not prevent streaming when cache is unavailable. */ }
        }
    }
    public static String title(JSONObject device) {
        JSONObject traits = device.optJSONObject("traits");
        if (traits != null) {
            JSONObject info = traits.optJSONObject("sdm.devices.traits.Info");
            if (info != null && !info.optString("customName").isEmpty()) return info.optString("customName");
        }
        JSONArray parents = device.optJSONArray("parentRelations");
        if (parents != null && parents.length() > 0) {
            JSONObject parent = parents.optJSONObject(0);
            String room = parent == null ? "" : parent.optString("displayName");
            if (!room.isEmpty()) return room;
        }
        return device.optString("type", "Nest Cam");
    }
    public static boolean webrtc(JSONObject d) {
        JSONObject traits = d.optJSONObject("traits");
        if (traits == null) return false;
        JSONObject live = traits.optJSONObject("sdm.devices.traits.CameraLiveStream");
        if (live == null) return false;
        JSONArray protocols = live.optJSONArray("supportedProtocols");
        if (protocols == null) return false;
        for (int i=0;i<protocols.length();i++) if ("WEB_RTC".equals(protocols.optString(i))) return true;
        return false;
    }
    public JSONObject execute(String deviceName, String command, JSONObject params) throws Exception {
        if (!deviceName.startsWith("enterprises/" + DEVICE_ACCESS_PROJECT + "/devices/")) throw new IllegalArgumentException("无效摄像头 ID");
        JSONObject body = new JSONObject().put("command", "sdm.devices.commands.CameraLiveStream." + command).put("params", params);
        JSONObject j = sdPost(API_ROOT + deviceName + ":executeCommand", body);
        return j.optJSONObject("results") == null ? new JSONObject() : j.getJSONObject("results");
    }
    public JSONObject start(String name, String sdp) throws Exception {
        if (!sdp.contains("m=application") || !sdp.contains("m=video") || !sdp.contains("m=audio"))
            throw new IllegalArgumentException("WebRTC SDP 必须包含 audio/video/data");
        return execute(name, "GenerateWebRtcStream", new JSONObject().put("offerSdp", sdp));
    }
    public JSONObject extend(String name, String session) throws Exception {
        return execute(name, "ExtendWebRtcStream", new JSONObject().put("mediaSessionId", session));
    }
    public void stop(String name, String session) throws Exception {
        if (!session.isEmpty()) execute(name, "StopWebRtcStream", new JSONObject().put("mediaSessionId", session));
    }
    private JSONObject sdGet(String url) throws Exception { return call("GET", url, token(), null, null); }
    private JSONObject sdPost(String url, JSONObject body) throws Exception {
        return call("POST", url, token(), body.toString().getBytes(StandardCharsets.UTF_8), "application/json");
    }
    private static JSONObject call(String method, String endpoint, String bearer, byte[] payload, String contentType) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(endpoint).openConnection();
        try {
            conn.setConnectTimeout(20000); conn.setReadTimeout(25000);
            conn.setRequestMethod(method); conn.setUseCaches(false);
            if (bearer != null) conn.setRequestProperty("Authorization", "Bearer " + bearer);
            if (payload != null) {
                conn.setDoOutput(true); conn.setRequestProperty("Content-Type", contentType);
                try (java.io.OutputStream os = conn.getOutputStream()) { os.write(payload); }
            }
            int status = conn.getResponseCode();
            InputStream stream = status < 400 ? conn.getInputStream() : conn.getErrorStream();
            byte[] bytes = read(stream);
            String raw = new String(bytes, StandardCharsets.UTF_8);
            JSONObject result = raw.isEmpty() ? new JSONObject() : new JSONObject(raw);
            if (status < 200 || status >= 300) {
                Object err = result.opt("error");
                String reason = err instanceof JSONObject ? ((JSONObject)err).optString("status", "API_ERROR")
                            : result.optString("error", "API_ERROR");
                if (reason.length() > 70) reason = reason.substring(0, 70);
                throw new IOException("HTTP " + status + " / " + reason);
            }
            return result;
        } finally { conn.disconnect(); }
    }
    private static byte[] read(InputStream in) throws IOException {
        if (in == null) return new byte[0];
        try (InputStream source = in; ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buf = new byte[4096]; int n;
            while ((n=source.read(buf)) != -1) { out.write(buf,0,n); if (out.size() > 3000000) throw new IOException("响应过大"); }
            return out.toByteArray();
        }
    }
}
