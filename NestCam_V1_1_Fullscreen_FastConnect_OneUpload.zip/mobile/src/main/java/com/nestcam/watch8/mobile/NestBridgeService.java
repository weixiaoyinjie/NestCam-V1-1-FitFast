package com.nestcam.watch8.mobile;

import com.google.android.gms.wearable.MessageEvent;
import com.google.android.gms.wearable.Wearable;
import com.google.android.gms.wearable.WearableListenerService;
import org.json.JSONArray;
import org.json.JSONObject;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Phone mediates OAuth/API only; video remains end-to-end WebRTC Nest -> Watch. */
public class NestBridgeService extends WearableListenerService {
    public static final String REQUEST = "/nestcam/v1/request";
    public static final String RESPONSE = "/nestcam/v1/response";
    private static final ExecutorService WORKER = Executors.newSingleThreadExecutor();
    private static final Map<String, Session> SESSIONS = new ConcurrentHashMap<>();
    private static class Session {
        String device; String media;
        Session(String device,String media) { this.device=device; this.media=media; }
    }

    @Override public void onMessageReceived(MessageEvent message) {
        if (!REQUEST.equals(message.getPath())) return;
        byte[] original = message.getData();
        String nodeId = message.getSourceNodeId();
        if (original.length > 90000) return;
        WORKER.execute(() -> {
            JSONObject reply = new JSONObject();
            try {
                JSONObject req = new JSONObject(new String(original, StandardCharsets.UTF_8));
                String type = req.optString("cmd");
                reply.put("cmd", type);
                reply.put("req", req.optString("req"));
                NestApi api = new NestApi(getApplicationContext());
                if ("LIST".equals(type)) {
                    JSONArray list = req.optBoolean("force", false) ? api.devices() : api.devicesPreferCached();
                    JSONArray clean = new JSONArray();
                    for (int i=0;i<list.length();i++) {
                        JSONObject d = list.getJSONObject(i);
                        if (NestApi.webrtc(d)) {
                            clean.put(new JSONObject().put("name", NestApi.title(d)).put("id", d.optString("name")));
                        }
                    }
                    reply.put("devices", clean);
                } else if ("START".equals(type)) {
                    String deviceName = req.getString("device");
                    String offer = req.getString("offer");
                    Session previous = SESSIONS.remove(nodeId);
                    if (previous != null) {
                        try { api.stop(previous.device, previous.media); } catch (Exception ignored) {}
                    }
                    JSONObject answer = api.start(deviceName, offer);
                    SESSIONS.put(nodeId, new Session(deviceName, answer.getString("mediaSessionId")));
                    reply.put("answer", answer.getString("answerSdp"));
                    reply.put("expiresAt", answer.optString("expiresAt"));
                } else if ("EXTEND".equals(type)) {
                    Session session = SESSIONS.get(nodeId);
                    if (session == null) throw new IllegalArgumentException("没有活跃的直播会话");
                    JSONObject result = api.extend(session.device, session.media);
                    reply.put("expiresAt", result.optString("expiresAt"));
                } else if ("STOP".equals(type)) {
                    Session session = SESSIONS.remove(nodeId);
                    if (session != null) api.stop(session.device, session.media);
                } else {
                    throw new IllegalArgumentException("未知命令");
                }
                reply.put("ok", true);
            } catch (Exception e) {
                try {
                    reply.put("ok", false);
                    reply.put("message", e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage());
                } catch (Exception ignored) {}
            }
            Wearable.getMessageClient(getApplicationContext()).sendMessage(nodeId, RESPONSE,
                    reply.toString().getBytes(StandardCharsets.UTF_8));
        });
    }
}
