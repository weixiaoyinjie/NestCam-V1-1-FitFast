# 仅改动清单（对照上传的 V1.0 源码）

- mobile/MainActivity.java: 完整画面沉浸式横屏覆盖层；复用相同 SurfaceViewRenderer；加载本地缓存
- mobile/NestApi.java: 在原本的 SecureStore 中缓存摄像头设备元数据/上次设备 ID；不缓存或跳过直播会话
- mobile/NestBridgeService.java: Wear LIST 默认走缓存，`force=true` 调用原 API 更新
- mobile/AndroidManifest.xml: 只给原 MainActivity 添加旋转 configuration change，防止当前播放 Activity 被重建
- wear/WatchActivity.java: 点击画面进入/退出适配圆屏的全屏；在本机保存摄像头 ID；再次打开或重连直接开播；必要时手动强制重新识别
- mobile/build.gradle 和 wear/build.gradle: 仅升级 versionCode 从 1 至 2、versionName 为 1.1-fitfast
- build.yml: GitHub CI，打印签名证书对比结果

未改 shared 源码、SecureStore 逻辑、OAuth 访问与令牌处理、Google API 命令、WebRTC SDP/解码，以及原应用权限声明。
