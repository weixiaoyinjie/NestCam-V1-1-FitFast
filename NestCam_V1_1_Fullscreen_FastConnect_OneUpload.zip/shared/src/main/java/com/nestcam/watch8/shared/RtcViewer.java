package com.nestcam.watch8.shared;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import org.webrtc.*;
import java.util.Collections;
import java.util.concurrent.atomic.AtomicBoolean;

/** WebRTC receiver. The peer runs on the device displaying the actual video. */
public final class RtcViewer {
    public interface Listener {
        void onOffer(String offer);
        void onStatus(String text);
    }

    private final Context context;
    private final SurfaceViewRenderer renderer;
    private final Listener listener;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private EglBase egl;
    private PeerConnectionFactory factory;
    private PeerConnection pc;
    private DataChannel dataChannel;
    private VideoTrack videoTrack;
    private final AtomicBoolean offerSent = new AtomicBoolean(false);
    private volatile boolean localSet = false;

    public RtcViewer(Context context, SurfaceViewRenderer renderer, Listener listener) {
        this.context = context.getApplicationContext();
        this.renderer = renderer;
        this.listener = listener;
        PeerConnectionFactory.initialize(PeerConnectionFactory.InitializationOptions.builder(this.context).createInitializationOptions());
        egl = EglBase.create();
        renderer.init(egl.getEglBaseContext(), null);
        renderer.setScalingType(RendererCommon.ScalingType.SCALE_ASPECT_FIT);
        factory = PeerConnectionFactory.builder()
            .setVideoDecoderFactory(new DefaultVideoDecoderFactory(egl.getEglBaseContext()))
            .setVideoEncoderFactory(new DefaultVideoEncoderFactory(egl.getEglBaseContext(), true, true))
            .createPeerConnectionFactory();
    }

    private void status(String s) { ui.post(() -> listener.onStatus(s)); }

    public void start() {
        closePeer();
        offerSent.set(false);
        localSet = false;
        PeerConnection.RTCConfiguration config = new PeerConnection.RTCConfiguration(
            Collections.singletonList(PeerConnection.IceServer.builder("stun:stun.l.google.com:19302").createIceServer()));
        config.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN;
        pc = factory.createPeerConnection(config, new PeerConnection.Observer() {
            @Override public void onSignalingChange(PeerConnection.SignalingState s) {}
            @Override public void onIceConnectionChange(PeerConnection.IceConnectionState s) { status("ICE: " + s); }
            @Override public void onIceConnectionReceivingChange(boolean b) {}
            @Override public void onIceGatheringChange(PeerConnection.IceGatheringState s) {
                if (s == PeerConnection.IceGatheringState.COMPLETE) emitOffer();
            }
            @Override public void onIceCandidate(IceCandidate c) {}
            @Override public void onIceCandidatesRemoved(IceCandidate[] cs) {}
            @Override public void onAddStream(MediaStream s) {}
            @Override public void onRemoveStream(MediaStream s) {}
            @Override public void onDataChannel(DataChannel d) {}
            @Override public void onRenegotiationNeeded() {}
            @Override public void onAddTrack(RtpReceiver receiver, MediaStream[] streams) { attach(receiver.track()); }
            @Override public void onTrack(RtpTransceiver t) { attach(t.getReceiver().track()); }
        });
        if (pc == null) { status("无法创建 WebRTC 连接"); return; }
        RtpTransceiver.RtpTransceiverInit recv = new RtpTransceiver.RtpTransceiverInit(RtpTransceiver.RtpTransceiverDirection.RECV_ONLY);
        pc.addTransceiver(MediaStreamTrack.MediaType.MEDIA_TYPE_AUDIO, recv);
        pc.addTransceiver(MediaStreamTrack.MediaType.MEDIA_TYPE_VIDEO, recv);
        dataChannel = pc.createDataChannel("dataSendChannel", new DataChannel.Init());
        status("正在准备 SDP...");
        pc.createOffer(new Observer() {
            @Override public void onCreateFailure(String error) { status("SDP Offer 创建失败: " + error); }
            @Override public void onCreateSuccess(SessionDescription sd) {
                try {
                    SessionDescription safe = new SessionDescription(SessionDescription.Type.OFFER, NestSdp.restrict(sd.description));
                    pc.setLocalDescription(new Observer() {
                        @Override public void onSetSuccess() {
                            localSet = true;
                            if (pc != null && pc.iceGatheringState() == PeerConnection.IceGatheringState.COMPLETE) emitOffer();
                            // If the network never finishes gathering, let the SDM call report the actual error.
                            ui.postDelayed(() -> emitOffer(), 15000);
                        }
                        @Override public void onSetFailure(String error) { status("本机 SDP 设置失败: " + error); }
                    }, safe);
                } catch (Exception e) { status("SDP 不兼容: " + e.getMessage()); }
            }
        }, new MediaConstraints());
    }

    private synchronized void emitOffer() {
        if (pc == null || !localSet || !offerSent.compareAndSet(false, true)) return;
        SessionDescription offer = pc.getLocalDescription();
        if (offer != null) ui.post(() -> listener.onOffer(offer.description));
    }

    private void attach(MediaStreamTrack track) {
        if (!(track instanceof VideoTrack)) return;
        if (videoTrack != null) videoTrack.removeSink(renderer);
        videoTrack = (VideoTrack) track;
        videoTrack.addSink(renderer);
        status("视频轨道已连接");
    }

    public void setAnswer(String answerSdp) {
        if (pc == null) return;
        pc.setRemoteDescription(new Observer() {
            @Override public void onSetSuccess() { status("正在接收直播视频..."); }
            @Override public void onSetFailure(String reason) { status("直播 Answer 不兼容: " + reason); }
        }, new SessionDescription(SessionDescription.Type.ANSWER, answerSdp));
    }

    private void closePeer() {
        if (videoTrack != null) { videoTrack.removeSink(renderer); videoTrack = null; }
        if (dataChannel != null) { dataChannel.close(); dataChannel.dispose(); dataChannel = null; }
        if (pc != null) { pc.close(); pc.dispose(); pc = null; }
    }
    public void stop() { closePeer(); status("已停止"); }
    public void release() {
        closePeer();
        renderer.release();
        if (factory != null) { factory.dispose(); factory = null; }
        if (egl != null) { egl.release(); egl = null; }
    }

    private static class Observer implements SdpObserver {
        @Override public void onCreateSuccess(SessionDescription s) {}
        @Override public void onSetSuccess() {}
        @Override public void onCreateFailure(String s) {}
        @Override public void onSetFailure(String s) {}
    }
}
