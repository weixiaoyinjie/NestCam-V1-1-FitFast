# NestCam Live Watch8 V1.1 — 原可安装 V1.0 基础上最小改动

本项目以 2026-11-20 上传的 `mobile-debug.apk`、`wear-debug.apk` 和 `NestCam_Source_Bundle.zip` 为基准。已通过 APK manifest 核查：原版均为版本代码 1、版本名 `1.0`，相同包名 `com.nestcam.watch8`，targetSdk 34。改动后版本代码 2、版本名 `1.1-fitfast`，其余原有 Android SDK 设置保持不变。

## 仅修改的内容

1. **手机全屏**：原页面新增“⛶ 全屏横屏查看”按钮；点击进入沉浸式全屏、强制感应横屏（左右横屏）、保持原始比例 `SCALE_ASPECT_FIT`（黑边而不裁切）。按“退出全屏”或系统返回退出，恢复原先方向。全屏时仅移动当前 `SurfaceViewRenderer` 到覆盖层，不重建 WebRTC 连接，也不会修改 OAuth 或直播续期逻辑。
2. **手表全屏**：点击监控画面切换圆屏全屏，点击画面退出。为圆形表盘预留约 14% 的直径总边距，原始画面保持 FIT 避免四角被裁切。手表无需强制旋转。
3. **连接加快**：手机从已加密的本地记录读取上次支持 WebRTC 的摄像头；手表保存已选摄像头 ID，重新打开直接建立新的直播会话而不重复列出摄像头。手机的手动“刷新摄像头列表”仍会调用 Google API。手表长按摄像头名称可强制重新获取列表，若云端返回该设备 404/NOT_FOUND，也会重新识别一次。

**未修改**：原有 OAuth 和密钥保存机制、Google Nest SDP、WebRTC 播放器/编解码配置、直播时长续期/停止流程、原有手表按键功能、Wear Data Layer 消息路径、权限列表、应用包名、minSdk/targetSdk 与原 Google 设备访问配置。不增加短信、辅助功能、通知监听等敏感权限。

## 重要：安装签名和 Google Play Protect

本次上传的旧手机和手表 APK 使用相同的签名证书：

`SHA-256: E2:3E:FA:05:CC:BD:84:18:3C:0E:B9:41:EA:A0:0C:9C:54:95:5C:5E:5C:20:58:11:8D:FE:63:9C:CC:F7:A3:06`

**必须使用对应的原始私有签名密钥签名新 APK，才能在不卸载旧版的情况下覆盖安装。** APK 自身只含公钥证书，无法倒推出该私钥。GitHub Actions 每次使用全新 runner 自动生成的 debug 签名，未必匹配旧版。为便于有原始 `debug.keystore` 的用户复用，工作流支持在 GitHub Secrets 中配置 `NESTCAM_ORIGINAL_DEBUG_KEYSTORE_B64`（原 debug keystore 的 base64 文本）。不要把密钥上传到公开仓库，也不要把密钥发给聊天机器人。

Actions 日志会核对新 APK 的签名证书是否匹配上述原版 SHA-256。**即使签名匹配也不能保证 Google Play Protect 不会拦截**：它属于独立的安全扫描机制。请不要为安装测试而关闭 Play Protect，也不要删除目前能运行的旧版 App。

## GitHub 编译：完整解压上传或 ZIP 一次上传

**方式 A（推荐新仓库）：** 将本 ZIP 内文件解压上传到 GitHub 仓库根目录（包含隐藏 `.github/workflows/build.yml`），在 GitHub Actions > Build NestCam V1.1 Phone and Watch8 > Run workflow 中手动运行。

**方式 B（不想解压）：** 将完整 `NestCam_V1_1_Fullscreen_FastConnect_OneUpload.zip` 原样上传到现有仓库根目录，并将单独提供的 `NestCam_V1_1_Fullscreen_FastConnect_Build.yml` 内容保存为仓库的 `.github/workflows/build.yml`。工作流会自动解压位于仓库根目录、名称完全匹配的 ZIP 后构建。如果现有仓库已经有此工作流，只需替换/上传 ZIP。

编译环境：JDK17、Gradle8.11.1、AGP8.9.2、Android SDK35、play-services-wearable 20.0.1、WebRTC 150.7871.08。编译成功后下载两个 Artifacts：`NestCam-V1_1-Phone-APK` 和 `NestCam-V1_1-Watch8-APK`。

## 首次使用与快速连接

- 原版已授权的手机如能用相同签名升级，OAuth 本机数据会保留。升级后的第一次打开，请点一次“刷新摄像头列表”，建立本地加密摄像头缓存。
- 此后直接播放，下一次打开手表将使用上次选择的摄像头 ID 连接。缓存并非旧的直播会话，新直播仍需 Google SDM API 与 WebRTC 协商。
- 如果摄像头更名、设备已删除或重新绑定 Google 账号，手机可手动刷新；手表长按摄像头名称重新识别。
- 本源码包通过 XML 和 Java **语法**静态检查，但运行环境未提供 Android SDK/Gradle，因此尚未本地编译、真机测试或验证 Play Protect 结果。请先备份并保留原能运行的 APK。
